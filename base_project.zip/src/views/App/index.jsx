import React, { Fragment } from "react";
import CactusController from "../CactusController";

function App() {
  return (
    <Fragment>
      <CactusController />
    </Fragment>
  );
}

export default App;
