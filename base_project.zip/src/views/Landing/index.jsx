import React from "react";
import { connect } from "react-redux";
import MenuImplementation from "../../components/Menu/MenuImplementation";
import Homepage from "../../components/Homepage/Homepage";
import Accordion from "../../components/Accordion/Accordion";

function Landing(props) {
  function render() {
    return (
      <div>
        <MenuImplementation data={props.data} value={0} viewId={0} />
        <Homepage data={props.data} />
        <Accordion data={props.data} />
      </div>
    );
  }

  return render();
}

export default connect((state) => {
  return {};
}, null)(Landing);
