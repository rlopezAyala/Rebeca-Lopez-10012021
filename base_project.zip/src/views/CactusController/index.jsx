import React, { useState, useEffect, useRef } from "react";
import { connect } from "react-redux";
import Loader from "../../components/Loader/Loader";
import Alert from "@mui/material/Alert";
import { teal } from "@mui/material/colors";
import Stack from "@mui/material/Stack";
import Landing from "../Landing";
import HomepageView from "../../components/Homepage/Homepage";
import { getHomePageAsync } from "../../actions/homepage";

function HomePage(props = {}) {
  const [showLoader, setShowLoader] = useState(true);
  const [showError] = useState(false);
  const [invalidUser, setShowInvalidUser] = useState(false);
  const [invalidPassword, setInvalidPassword] = useState(false);
  const [passwordErrorText, setPasswordErrorText] = useState([]);

  useEffect(() => {
    props.dispatch(getHomePageAsync());
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const prevHomePage = useRef(props.homePage);
  useEffect(() => {
    const { homePage } = props;
    if (prevHomePage.current.data !== homePage.data) {
      if (homePage.data.credenciales) {
        if (homePage.data.credenciales && homePage.data.credenciales.user === "") {
          setShowInvalidUser(true);
        } else if (homePage.data.credenciales.password !== "") {
          validatePassword(homePage.data.credenciales.password);
        }
      }
      setShowLoader(false);
    }
  }, [props.homePage, props]);

  function validatePassword(passwordValue) {
    const passwordErrors = [];
    const atLeastOneMin = /^(?=.*[a-z])(?=.*[A-Z])[a-zA-Z#$&%*=]+$/; //Debe Contener al menos una mayúscula y minúscula

    const erroratLeastOneMin = atLeastOneMin.test(passwordValue);
    if (!erroratLeastOneMin) {
      passwordErrors.push("Debe contener al menos una letra mayúscula y una letra minúscula");
    }
    const oneCharacterDif = /^(?=.*[#$&%*=])[a-zA-Z#$&%*=]+$/;
    if (!oneCharacterDif.test(passwordValue)) {
      passwordErrors.push("Debe contener al menos un símbolo de los siguientes (#$%&*=)");
    }

    const maxLenght = /^[a-zA-Z#$&%*=]{8,}$/;

    if (!maxLenght.test(passwordValue)) {
      passwordErrors.push("Debe poseer una longitud mínima de 8 carácteres");
    }

    if (passwordErrors.length !== 0) {
      setPasswordErrorText(passwordErrors);
      setInvalidPassword(true);
    }
  }

  function renderLoader() {
    return <Loader color={teal} />;
  }

  function renderError() {
    return showError && <div>Error en la página ... </div>;
  }

  function renderInvalidUserError() {
    return (
      <Stack sx={{ display: { xs: "100%", md: "50%" } }} spacing={2}>
        <Alert severity="error">Usuario Inválido</Alert>
      </Stack>
    );
  }

  function renderInvalidPassword() {
    return (
      passwordErrorText &&
      passwordErrorText.map((item) => {
        return (
          <Stack sx={{ display: { xs: "100%", md: "50%" } }} spacing={2}>
            <Alert severity="error">{`Contraseña Incorrecta no cumple: ${item}`}</Alert>
          </Stack>
        );
      })
    );
  }

  function renderLanding() {
    return !invalidUser && !invalidPassword && props.homePage && props.homePage.data ? (
      <Landing data={props.homePage.data} />
    ) : (
      renderError()
    );
  }

  function render() {
    return (
      <div>
        {renderLanding()}
        {invalidUser && renderInvalidUserError()}
        {invalidPassword && renderInvalidPassword()}
      </div>
    );
  }

  return showLoader ? renderLoader() : render();
}

export default connect((state) => {
  return {
    menu: state.crud.get("menu"),
    homePage: state.homepage.get("homePage"),
  };
}, null)(HomePage);
