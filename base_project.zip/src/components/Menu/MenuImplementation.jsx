import React from "react";
import TopBar from "../../components/TopBar/TopBar";
import { connect } from "react-redux";

function MenuImplementation(props = {}) {
  function renderMenu() {
    return (
      <div>
        <TopBar data={props.data} />
      </div>
    );
  }

  return <div>{renderMenu()}</div>;
}
export default connect((state) => {
  return {
    menu: state.crud.get("menu"),
  };
}, null)(MenuImplementation);
