import React, { useEffect } from "react";
import { styled } from "@mui/system";
import { teal } from "@mui/material/colors";
import { useHistory } from "react-router-dom";
import AppBar from "@mui/material/AppBar";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import HomeIcon from "@material-ui/icons/Home";

import CookiesUtils from "../../utils/CookiesUtils";

const Div = styled("div")({
  flexGrow: 1,
  width: "100%",
});

const NewAppBar = styled(AppBar)({
  backgroundColor: teal["900"],
});

function a11yProps(index) {
  return {
    id: `scrollable-force-tab-${index}`,
    "aria-controls": `scrollable-force-tabpanel-${index}`,
  };
}

function Menu(props) {
  let history = useHistory();

  const [value, setValue] = React.useState(0);
  const [logged, setLogged] = React.useState(false);

  useEffect(() => {
    const islogged = CookiesUtils.getCookie("logged");
    if (islogged) {
      setLogged(islogged);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleChange = (event, newValue) => {
    history.push(props.items[newValue].url);
    setValue(newValue);
  };

  function renderTabs() {
    return logged ? renderLoggedTabs() : <Tab icon={<HomeIcon />} {...a11yProps(0)} />;
  }

  function renderLoggedTabs() {
    const { items, hasHomepage } = props;
    return (
      items &&
      items.map((item, id) => {
        return hasHomepage && id === 0 ? (
          <Tab key={id} icon={<HomeIcon />} {...a11yProps(id)} />
        ) : (
          <Tab key={id} label={`${item.label}`} {...a11yProps(id)} />
        );
      })
    );
  }
  function render() {
    return (
      <Div>
        <NewAppBar position="static">
          <Tabs
            value={props.value}
            onChange={handleChange}
            variant="scrollable"
            scrollButtons="auto"
            indicatorColor="primary"
            textColor="inherit"
            aria-label="scrollable force tabs example"
          >
            {renderTabs()}
          </Tabs>
        </NewAppBar>
      </Div>
    );
  }

  return render();
}

export default Menu;
