import { styled } from "@mui/system";
import CircularProgress from "@mui/material/CircularProgress";
import Paper from "@mui/material/Paper";
import FormControl from "@mui/material/FormControl";
import { lightGreen, teal } from "@mui/material/colors";
import Button from "../../components/Button/Button";

export const NewButtonSignIn = styled(Button)({
  backgroundColor: lightGreen[500],
  backgroundImage: `linear-gradient(${lightGreen[500]}, ${teal[900]})`,
});

export const NewCircularProgress = styled(CircularProgress)({
  color: "#BA55D3",
  position: "absolute",
  top: "50%",
  left: "50%",
  marginTop: -12,
  marginLeft: -12,
});

export const NewFormControl = styled(FormControl)({
  marginTop: "1rem",
});

export const NewPaper = styled(Paper)({
  width: "50%",
});
