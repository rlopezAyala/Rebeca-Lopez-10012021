import React, { useState } from "react";
import { connect } from "react-redux";
import Input from "@mui/material/Input";
import InputLabel from "@mui/material/InputLabel";
import InputAdornment from "@mui/material/InputAdornment";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import IconButton from "@mui/material/IconButton";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import { NewButtonSignIn, NewCircularProgress, NewFormControl, NewPaper } from "./SignInStyle";

import "./SignIn.scss";

function SignIn(props) {
  const [loading, setLoading] = useState(false);
  const [values, setValues] = useState({
    password: "",
    username: "",
    showPassword: false,
  });

  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value });
  };

  const handleClickShowPassword = () => {
    setValues({ ...values, showPassword: !values.showPassword });
  };

  function handleButtonClick() {
    setLoading(!loading);
    props.authenticate(values);
  }

  function renderPassword() {
    return (
      <NewFormControl>
        <InputLabel htmlFor="standard-adornment-password">Password</InputLabel>
        <Input
          id="standard-adornment-password"
          type={values.showPassword ? "text" : "password"}
          value={values && values.password}
          onChange={handleChange("password")}
          endAdornment={
            <InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={handleClickShowPassword}
                //onMouseDown={handleMouseDownPassword}
              >
                {values.showPassword ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </InputAdornment>
          }
        />
      </NewFormControl>
    );
  }

  function renderUserName() {
    return (
      <NewFormControl>
        <InputLabel htmlFor="standard-adornment-password">Username</InputLabel>
        <Input
          id="standard-adornment-password"
          type={"text"}
          value={values.username}
          onChange={handleChange("username")}
          endAdornment={
            <InputAdornment position="end">
              <AccountCircleIcon />
            </InputAdornment>
          }
        />
      </NewFormControl>
    );
  }

  function render() {
    return (
      <div className={"paperWrapper"}>
        <NewPaper elevation={3}>
          <div className={"sgnwrapper"}>
            <h1>Login</h1>
            {renderUserName()}
            {renderPassword()}
            <NewButtonSignIn label="Log In" disabled={loading} onClick={handleButtonClick}>
              {loading && <NewCircularProgress size={24} />}
            </NewButtonSignIn>
          </div>
        </NewPaper>
      </div>
    );
  }

  return render();
}

export default connect((state) => {
  return {
    authentication: state.authentication.get("authentication"),
  };
}, null)(SignIn);
