import * as React from "react";
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";

export default function MediaCard(props) {
  function render() {
    const { data } = props;

    const gotoPage = (event) => {
      window.open(props.data.playerWebSite, "_blank");
    };

    return (
      <Card sx={{ maxWidth: "100%" }}>
        <Box sx={{ display: "flex", flexDirection: "row" }}>
          <div onClick={gotoPage}>
            <CardMedia component="img" height="140" sx={{ width: 151 }} image={data.playerImg} alt={data.playerNombre} />
          </div>
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              {`${data.playerNombre} ${data.playerApellido}`}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              <b>{data.playerEdad} </b>
              <br></br>
              <br></br>
              <b>{data.playerPasatiempo} </b>
              <br></br>
              <br></br>
              <b>{data.playerWebSite} </b>
              <br></br>
              <br></br>
              <b>{data.playerProfesion} </b>
              <br></br>
              <br></br>
            </Typography>
          </CardContent>
        </Box>
      </Card>
    );
  }

  return render();
}
