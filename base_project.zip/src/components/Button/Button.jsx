import React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/system";
import SaveIcon from "@material-ui/icons/Save";
import "./Button.scss";

const NewButton = styled(Button)({
  margin: "1rem",
  backgroundColor: "#800080",
  color: "white",
});

export default function ButtonView(props) {
  return (
    <div className="buttonwrapper">
      <NewButton
        onClick={props.onClick}
        variant="contained"
        size={props.size}
        startIcon={props.icon ? <props.icon /> : <SaveIcon />}
      >
        {props.label}
      </NewButton>
    </div>
  );
}
