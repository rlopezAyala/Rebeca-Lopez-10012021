import React from "react";
import { styled } from "@mui/system";
import TextField from "@mui/material/TextField";

const DivWrapper = styled("div")({
  display: "flex",
  flexWrap: "wrap",
  padding: "2rem",
});

const NewTextField = styled(TextField)(({ theme }) => ({
  margin: theme.spacing(1),
  width: "25ch",
}));
/*
withoutLabel: {
    marginTop: theme.spacing(3),
  },*/

function PersonalInfo(props = {}) {
  const [values, setValues] = React.useState({
    amount: "",
    password: "",
    weight: "",
    weightRange: "",
    showPassword: false,
  });

  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value });
  };

  const handleClickShowPassword = () => {
    setValues({ ...values, showPassword: !values.showPassword });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  function getLabel(array, string) {
    return (
      array &&
      array.find((item) => {
        return item.id == string;
      })
    );
  }

  function personalData() {
    const { data } = props;
    //name, lastName, age, phone, address
    const name = getLabel(data.inputText, "name");
    const lastname = getLabel(data.inputText, "lastname");
    const address = getLabel(data.inputText, "address");
    const desc = getLabel(data.inputText, "desc");
    return (
      <div>
        <NewTextField
          label={name.label}
          id={name.id} //onChange
        />
        <NewTextField label={lastname.label} id={lastname.id} />
        <NewTextField label={address.label} id={address.id} />
        <NewTextField label={desc.label} id={desc.id} />
      </div>
    );
  }

  function render() {
    return <DivWrapper>{props.data && personalData()}</DivWrapper>;
  }

  return render();
}

export default PersonalInfo;
