import React from "react";

export default function Loader(props) {
  return (
    <div>
      <img src={props.src} alt={props.imageTitle} />
    </div>
  );
}
