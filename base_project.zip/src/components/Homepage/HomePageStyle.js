import { styled } from "@mui/system";
import Paper from "@mui/material/Paper";

export const NewPaper = styled(Paper)(({ theme }) => ({
  width: "50%",
  marginLeft: "0px !important",
  padding:"3rem",
  [theme.breakpoints.down('sm')]: {
    width: "72%"
  },
}));

export const DivImageWrapper = styled("div")(({ theme }) => ({
  backgroundColor: "transparent",
  width: "80%",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  margin:" 0 auto",
  marginTop: "2rem",
  overflow: "hidden",
  height: "400px",

  [theme.breakpoints.down('sm')]: {
    width: "100%",
  },
}));

export const ImgStyle = styled("img")({
  width: "100%",
});



export const H4Styled = styled("h4")({
 margin: "0 auto  !important",
 marginTop: "2rem !important",
 marginBottom: "2rem  !important",
});
