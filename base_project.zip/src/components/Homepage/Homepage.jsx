import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import Stack from "@mui/material/Stack";
import { DivImageWrapper, ImgStyle, H4Styled } from "./HomePageStyle";
import Grow from "@mui/material/Grow";

function HomePage(props) {
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    setChecked(true);
  }, []);

  const handleDivClick = (event) => {
    if (props.data.header.newWindowBanner) {
      window.open(props.data.header.bannerUrl, "_blank");
    } else {
      window.location.href = props.data.header.bannerUrl;
    }
  };

  function render() {
    const show = props.data && props.data.header && props.data.header.bannerImg;
    return (
      show && (
        <div className={"homepagePaperWrapper"}>
          <Stack direction={{ xs: "column", sm: "column" }} spacing={2}>
            <Grow in={checked}>
              <DivImageWrapper onClick={handleDivClick}>
                <ImgStyle alt="Background Logo" src={`${props.data.header.bannerImg}`} />
              </DivImageWrapper>
            </Grow>
            <H4Styled sx={{ color: props.data.header.tituloColor, fontSize: props.data.header.tituloFontSize }}>
              {props.data && props.data.header.tituloBienvenida}
            </H4Styled>
          </Stack>
        </div>
      )
    );
  }

  return render();
}

export default connect((state) => {
  return {
    menu: state.crud.get("menu"),
    homePage: state.homepage.get("homePage"),
  };
}, null)(HomePage);
