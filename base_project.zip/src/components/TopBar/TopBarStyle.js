import { styled } from "@mui/material/styles";
import { lightGreen, teal } from "@mui/material/colors";
import AppBar from "@mui/material/AppBar";
  
  export const AppBarWrapper = styled(AppBar)({
    backgroundColor: lightGreen[500],
    backgroundImage: `linear-gradient(${lightGreen[500]}, ${teal[900]})`,
  });

  
export const ImgStyle = styled("img")({
  width: "2rem",
});

  