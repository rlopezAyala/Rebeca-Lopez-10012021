import * as React from "react";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import { AppBarWrapper, ImgStyle } from "./TopBarStyle";

export default function PrimarySearchAppBar(props) {
  const handleProfileMenuOpen = (event) => {
    if (props.data.header.newWindowLogo) {
      window.open(props.data.header.logoURL, "_blank");
    } else {
      window.location.href = props.data.header.logoURL;
    }
  };

  function render() {
    return (
      <Box sx={{ flexGrow: 1 }}>
        <AppBarWrapper position="static">
          <Toolbar>
            <Typography variant="h6" noWrap component="div" sx={{ display: { xs: "none", sm: "block" } }}>
              {props.data.header.nombre}
            </Typography>
            <Box sx={{ flexGrow: 1 }} />
            <Box sx={{ display: { xs: "none", md: "flex" } }}>
              <IconButton
                size="large"
                edge="end"
                aria-label="account icon"
                aria-haspopup="true"
                onClick={handleProfileMenuOpen}
                color="inherit"
              >
                <ImgStyle
                  style={{
                    width: "2rem",
                  }}
                  src={props.data.header.logoImg}
                  alt="logo_image"
                />
              </IconButton>
            </Box>
          </Toolbar>
        </AppBarWrapper>
      </Box>
    );
  }

  return render();
}
