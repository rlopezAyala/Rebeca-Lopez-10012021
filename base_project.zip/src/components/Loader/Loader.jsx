import React from "react";
import { styled } from "@mui/system";
import CircularProgress from "@mui/material/CircularProgress";

const NewDiv = styled("div")({
  display: "flex",
  "& > * + *": {
    marginLeft: "2rem",
  },
  marginTop: "20%",
  justifyContent: "center",
});

export default function Loader(props) {
  return (
    <NewDiv>
      <CircularProgress sx={{ color: props.color }} />
    </NewDiv>
  );
}
