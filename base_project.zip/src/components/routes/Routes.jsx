import React, { useEffect } from "react";
import { Route, Switch, useHistory } from "react-router-dom";
import PropTypes from "prop-types";
import HomePage from "../../views/HomePage";
import Profile from "../../views/Profile";
import SignIn from "../../views/SignIn";
import CookiesUtils from "../../utils/CookiesUtils";

function Routes() {
  const history = useHistory();
  useEffect(() => {
    const islogged = CookiesUtils.getCookie("logged");
    if (!islogged) {
      history.push("/sign-in");
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Switch>
      <Route path={"/profile"} component={Profile} />
      <Route path={"/sign-in"} component={SignIn} />
      <Route path={"/"} component={HomePage} />
    </Switch>
  );
}

Routes.propTypes = {
  location: PropTypes.object,
};

export default Routes;
