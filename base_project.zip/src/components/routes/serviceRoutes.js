const ROUTES = {
    homePage:"https://private-7be349-exam32.apiary-mock.com/cactus-info",
    menu: "https://private-7469b-micrositios.apiary-mock.com/menu",
    authentication:"https://private-7469b-micrositios.apiary-mock.com/authentication",
    signinView:"https://private-7469b-micrositios.apiary-mock.com/signin", 
    profileForm:"https://private-7469b-micrositios.apiary-mock.com/profileform",
};

export default ROUTES;