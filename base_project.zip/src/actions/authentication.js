import api from "../api/authentication";

export const GET_AUTHENTICATION_ACTION_START = "GET_AUTHENTICATION_ACTION_START";
export const GET_AUTHENTICATION_ACTION_SUCCESS = "GET_AUTHENTICATION_ACTION_SUCCESS";
export const GET_AUTHENTICATION_ACTION_ERROR = "GET_AUTHENTICATION_ACTION_ERROR";

function getAuthenticationActionStart() {
  return {
    type: GET_AUTHENTICATION_ACTION_START
  };
}

function getAuthenticationActionSuccess(data) {
  return {
    type: GET_AUTHENTICATION_ACTION_SUCCESS,
    data
  };
}

function getAuthenticationActionError(error) {
  return {
    type: GET_AUTHENTICATION_ACTION_ERROR,
    error
  };
}

export function getAuthenticationAsync(data) {
  return function(dispatch) {
    dispatch(getAuthenticationActionStart());
    api
      .getAuthenticationAsync(data)
      .then(response => {
        const statusCode = response.status;
        if (statusCode === 200) {
          return response.json();
        } else {
            dispatch(getAuthenticationActionError())
        }
        return false;
      }).then(response => {
        if (response) {
            dispatch(getAuthenticationActionSuccess(response));
        } else {
          dispatch(getAuthenticationActionError());
        }
      }).catch(() => dispatch(getAuthenticationActionError()))
  };
}