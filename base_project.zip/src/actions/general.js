export const SHOW_LOADER = "SHOW_LOADER";

export function setShowLoader(data) {
  return {
    type: SHOW_LOADER,
    data
  };
}
