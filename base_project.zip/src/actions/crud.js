import api from "../api/crud";

export const GET_MENU_DATA_ACTION_START = "GET_MENU_DATA_ACTION_START";
export const GET_MENU_DATA_ACTION_SUCCESS = "GET_MENU_DATA_ACTION_SUCCESS";
export const GET_MENU_DATA_ACTION_ERROR = "GET_MENU_DATA_ACTION_ERROR";

function getMenuDataActionStart() {
  return {
    type: GET_MENU_DATA_ACTION_START
  };
}

function getMenuDataActionSuccess(data) {
  return {
    type: GET_MENU_DATA_ACTION_SUCCESS,
    data
  };
}

function getMenuDataActionError(error) {
  return {
    type: GET_MENU_DATA_ACTION_ERROR,
    error
  };
}

export function getMenuDataAsync() {
  return function(dispatch) {
    dispatch(getMenuDataActionStart());
    api
      .getMenuDataAsync()
      .then(response => {
        const statusCode = response.status;
        if (statusCode === 200) {
          return response.json();
        } else {
            dispatch(getMenuDataActionError())
        }
        return false;
      }).then(response => {
        if (response) {
            dispatch(getMenuDataActionSuccess(response));
        } else {
          dispatch(getMenuDataActionError());
        }
      }).catch(() => dispatch(getMenuDataActionError()))
  };
}