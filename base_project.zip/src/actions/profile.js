import api from "../api/profile";

export const GET_PROFILE_VIEW_ACTION_START = "GET_PROFILE_VIEW_ACTION_START";
export const GET_PROFILE_VIEW_ACTION_SUCCESS = "GET_PROFILE_VIEW_ACTION_SUCCESS";
export const GET_PROFILE_VIEW_ACTION_ERROR = "GET_PROFILE_VIEW_ACTION_ERROR";

function getProfileViewActionStart() {
  return {
    type: GET_PROFILE_VIEW_ACTION_START
  };
}

function getProfileViewActionSuccess(data) {
  return {
    type: GET_PROFILE_VIEW_ACTION_SUCCESS,
    data
  };
}

function getProfileViewActionError(error) {
  return {
    type: GET_PROFILE_VIEW_ACTION_ERROR,
    error
  };
}

export function getProfileViewAsync() {
  return function(dispatch) {
    dispatch(getProfileViewActionStart());
    api
      .getProfileViewAsync()
      .then(response => {
        const statusCode = response.status;
        if (statusCode === 200) {
          return response.json();
        } else {
            dispatch(getProfileViewActionError())
        }
        return false;
      }).then(response => {
        if (response) {
            dispatch(getProfileViewActionSuccess(response));
        } else {
          dispatch(getProfileViewActionError());
        }
      }).catch(() => dispatch(getProfileViewActionError()))
  };
}