import api from "../api/homepage";

export const GET_HOMEPAGE_ACTION_START = "GET_HOMEPAGE_ACTION_START";
export const GET_HOMEPAGE_ACTION_SUCCESS = "GET_HOMEPAGE_ACTION_SUCCESS";
export const GET_HOMEPAGE_ACTION_ERROR = "GET_HOMEPAGE_ACTION_ERROR";

function getHomePageActionStart() {
  return {
    type: GET_HOMEPAGE_ACTION_START
  };
}

function getHomePageActionSuccess(data) {
  return {
    type: GET_HOMEPAGE_ACTION_SUCCESS,
    data
  };
}

function getHomePageActionError(error) {
  return {
    type: GET_HOMEPAGE_ACTION_ERROR,
    error
  };
}

export function getHomePageAsync() {
  return function(dispatch) {
    dispatch(getHomePageActionStart());
    api
      .getHomePageAsync()
      .then(response => {
        const statusCode = response.status;
        if (statusCode === 200) {
          return response.json();
        } else {
            dispatch(getHomePageActionError())
        }
        return false;
      }).then(response => {
        if (response) {
            dispatch(getHomePageActionSuccess(response));
        } else {
          dispatch(getHomePageActionError());
        }
      }).catch(() => dispatch(getHomePageActionError()))
  };
}