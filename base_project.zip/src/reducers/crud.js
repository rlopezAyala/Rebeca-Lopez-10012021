import { Map } from "immutable";
import {
  GET_MENU_DATA_ACTION_START,
  GET_MENU_DATA_ACTION_SUCCESS,
  GET_MENU_DATA_ACTION_ERROR,
} from "../actions/crud";

const initialState = Map({
    menu:{
        loading:false,
        ended:false,
        data:null
    }
});

const actionsMap = {
  //Seteando variable redux lenguaje
  [GET_MENU_DATA_ACTION_START]: state => {
    return state.merge(
      Map({
        menu: {
            loading:true,
            ended:false,
            data:null
        }
      })
    );
  },
  [GET_MENU_DATA_ACTION_SUCCESS]: (state, action) => {
    return state.merge(
      Map({
        menu: {    
            loading:false,
            ended:true,
            data:action.data
        }
      })
    );
  },
  [GET_MENU_DATA_ACTION_ERROR]: (state, action) => {
    return state.merge(
      Map({
        menu: {
            loading:false,
            ended:true,            
            error:action.error
        }
      })
    );
  }
};

export default function reducer(state = initialState, action = {}) {
  const fn = actionsMap[action.type];
  return fn ? fn(state, action) : state;
}
