import { Map } from "immutable";
import {
  SHOW_LOADER,
} from "../actions/general";

const initialState = Map({
    showLoader:null
});

const actionsMap = {
  [SHOW_LOADER]: (state, action) => {
    return state.merge(
      Map({
        showLoader: action.data
      })
    );
  }
};

export default function reducer(state = initialState, action = {}) {
  const fn = actionsMap[action.type];
  return fn ? fn(state, action) : state;
}
