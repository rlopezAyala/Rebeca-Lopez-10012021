import { combineReducers } from "redux";
import crud from "./crud";
import homepage from "./homepage";
import general from "./general";
import authentication from "./authentication";
import profile from "./profile";

export default combineReducers({
    crud,
    general,
    authentication,
    profile, 
    homepage
});
