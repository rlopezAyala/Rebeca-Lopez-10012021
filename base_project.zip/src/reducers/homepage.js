import { Map } from "immutable";
import {
  GET_HOMEPAGE_ACTION_START,
  GET_HOMEPAGE_ACTION_SUCCESS,
  GET_HOMEPAGE_ACTION_ERROR,
} from "../actions/homepage";

const initialState = Map({
    homePage:{
        ended:false,
        data:null
    }
});

const actionsMap = {
  //Seteando variable redux lenguaje
  [GET_HOMEPAGE_ACTION_START]: state => {
    return state.merge(
      Map({
        homePage: {
            ended:false,
            data:null
        }
      })
    );
  },
  [GET_HOMEPAGE_ACTION_SUCCESS]: (state, action) => {
    return state.merge(
      Map({
        homePage: {    
            ended:true,
            data:action.data
        }
      })
    );
  },
  [GET_HOMEPAGE_ACTION_ERROR]: (state, action) => {
    return state.merge(
      Map({
        homePage: {
            ended:true,            
            error:action.error
        }
      })
    );
  }
};

export default function reducer(state = initialState, action = {}) {
  const fn = actionsMap[action.type];
  return fn ? fn(state, action) : state;
}
