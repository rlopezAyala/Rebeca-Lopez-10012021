import { Map } from "immutable";
import {
  GET_AUTHENTICATION_ACTION_START,
  GET_AUTHENTICATION_ACTION_SUCCESS,
  GET_AUTHENTICATION_ACTION_ERROR,
} from "../actions/authentication";

const initialState = Map({
    authentication:{
        ended:false,
        data:null
    }
});

const actionsMap = {
  //Seteando variable redux lenguaje
  [GET_AUTHENTICATION_ACTION_START]: state => {
    return state.merge(
      Map({
        authentication: {
            ended:false,
            data:null
        }
      })
    );
  },
  [GET_AUTHENTICATION_ACTION_SUCCESS]: (state, action) => {
    return state.merge(
      Map({
        authentication: {    
            ended:true,
            data:action.data
        }
      })
    );
  },
  [GET_AUTHENTICATION_ACTION_ERROR]: (state, action) => {
    return state.merge(
      Map({
        authentication: {
            ended:true,            
            error:action.error
        }
      })
    );
  }
};

export default function reducer(state = initialState, action = {}) {
  const fn = actionsMap[action.type];
  return fn ? fn(state, action) : state;
}
