

import CookiesUtils from "../../utils/CookiesUtils";

export function isLogged(){
    return CookiesUtils.getCookie("logged");
}