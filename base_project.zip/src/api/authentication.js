import "whatwg-fetch";
import ROUTES from "../components/routes/serviceRoutes";

function getAuthenticationAsync(data) {
  const hostUrl = ROUTES.authentication;  
  const request = {
    method: "POST",
    headers: {
      Accept: "application/json"
    },
    body: JSON.stringify(data),
  };

  if (hostUrl) {
    return fetch(hostUrl, request).then(response => {
      return response;
    });
  }
}

export default {
    getAuthenticationAsync
};