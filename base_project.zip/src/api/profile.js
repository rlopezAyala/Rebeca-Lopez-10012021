import "whatwg-fetch";
import ROUTES from "../components/routes/serviceRoutes";

function getProfileViewAsync() {
  const hostUrl = ROUTES.profileForm;  
  if (hostUrl) {
    return fetch(hostUrl).then(response => {
      return response;
    });
  }
}

const profileFunc = {
    getProfileViewAsync
};

export default profileFunc
