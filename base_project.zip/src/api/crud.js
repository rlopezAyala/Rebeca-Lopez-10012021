import "whatwg-fetch";
import ROUTES from "../components/routes/serviceRoutes";

function getMenuDataAsync() {
  const hostUrl = ROUTES.menu;

  const request = {
    method: "GET",
    headers: {
      Accept: "application/json",
      ["Access-Control-Allow-Origin"]: "*"
    },
  };
  if (hostUrl) {
    return fetch(hostUrl, request).then(response => {
      return response;
    });
  }
}

const allFunc = {
  getMenuDataAsync
} 

export default allFunc;