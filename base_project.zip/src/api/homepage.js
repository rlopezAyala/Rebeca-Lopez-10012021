import "whatwg-fetch";
import ROUTES from "../components/routes/serviceRoutes";

function getHomePageAsync() {
  const hostUrl = ROUTES.homePage;  
  if (hostUrl) {
    return fetch(hostUrl).then(response => {
      return response;
    });
  }
}

const homePageFunc = {
    getHomePageAsync
};

export default homePageFunc
