import jwt from "jsonwebtoken";

export function generateJwt(data){
    return jwt.sign(data, "signin");
}