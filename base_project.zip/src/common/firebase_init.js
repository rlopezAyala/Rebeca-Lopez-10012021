
import firebase from "firebase/app";
import 'firebase/firestore';

export function init_app(){
    try {
      const firebaseConfig = {
        apiKey: "AIzaSyAFxqz2jvYBxfPwFlVEFkqEKwY93IR4BoE",
        authDomain: "examen-38232.firebaseapp.com",
        projectId: "examen-38232",
        storageBucket: "examen-38232.appspot.com",
        messagingSenderId: "853305731492",
        appId: "1:853305731492:web:09f047815d90b148d5b931",
        measurementId: "G-F9FQ4EC0T2"
      };
      
      console.log("****************************************************DATA ");
      
      // Initialize Firebase
      firebase.initializeApp(firebaseConfig);
      return firebase.firestore()
  } catch (e) {
    console.error("Error creating database: ", e);
  }
}

export async function addData(database, newData, db, id) {
  try {
      db.collection(database).doc(id).set(newData)
      .then((docRef) => {
          console.log("Document written with ID: ", id);
      })
      .catch((error) => {
          console.error("Error adding document: ", error);
      });
  } catch (e) {
    console.error("Error adding document: ", e);
  }
}

export async function readDataByValue(database, db, value, id) {
  try {
    db.collection(database).where(value, "==", id)
        .onSnapshot((querySnapshot) => {
            var newData = [];
            querySnapshot.forEach((doc) => {
                newData.push(doc.data().name);
            });
            console.log("Current cities in CA: ", newData.join(", "));
        });
  } catch (e) {
    console.error("Error adding document: ", e);
  }
}
